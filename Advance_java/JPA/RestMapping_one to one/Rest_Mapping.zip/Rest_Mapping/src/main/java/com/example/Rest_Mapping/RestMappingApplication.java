package com.example.Rest_Mapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestMappingApplication.class, args);
	}

}
