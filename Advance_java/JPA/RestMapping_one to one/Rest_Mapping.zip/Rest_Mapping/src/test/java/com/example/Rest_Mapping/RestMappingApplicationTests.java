package com.example.Rest_Mapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
