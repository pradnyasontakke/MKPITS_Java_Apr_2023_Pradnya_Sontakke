package com.example.demoRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
