package com.example.validationRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationRestApplication.class, args);
	}

}
