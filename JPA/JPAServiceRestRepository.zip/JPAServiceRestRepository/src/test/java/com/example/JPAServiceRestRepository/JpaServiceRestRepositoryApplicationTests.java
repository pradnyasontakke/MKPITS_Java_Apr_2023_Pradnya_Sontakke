package com.example.JPAServiceRestRepository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaServiceRestRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
