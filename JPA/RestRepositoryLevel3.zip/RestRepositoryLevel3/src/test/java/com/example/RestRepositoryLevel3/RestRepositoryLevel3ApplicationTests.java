package com.example.RestRepositoryLevel3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestRepositoryLevel3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
