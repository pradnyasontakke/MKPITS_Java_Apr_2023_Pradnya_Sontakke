package com.example.demo7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
