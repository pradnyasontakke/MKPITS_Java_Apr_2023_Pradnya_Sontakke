package com.example.demoServiceRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoServiceRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoServiceRestApplication.class, args);
	}

}
