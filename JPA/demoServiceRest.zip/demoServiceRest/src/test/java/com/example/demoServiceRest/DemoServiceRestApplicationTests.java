package com.example.demoServiceRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoServiceRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
